#### Running method
There should be five files after Decompressing the .zip file.
- File List
	- AS_JavaFx.jar
	- courses.csv
	- prerequisites.csv
	- work.sh
	- README.md
- running method:
	- open your cmd, direct to the project file
	- run "java -jar AS_JavaFx.jar"
	- or run "sh work.sh"
- Using guidance
	- Open the software with method above
	- select courses on the left hand side and press add button
	- Course will be selected as "courses done before"
	- After selecting courses, press submit button
	- Your study plan will be shown on the left hanside
	- level 0 means you can study them right now
	- after finish level 0 then you can study level 1 and then level 2 ...
	- press clear to clean the buffer and select again.
	 
