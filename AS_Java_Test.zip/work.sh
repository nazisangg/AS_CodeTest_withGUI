java -jar AS_JavaFx.jar
